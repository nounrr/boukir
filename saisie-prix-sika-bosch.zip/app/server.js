// Serveur de saisie des prix — Node.js 16+ sans dépendance.
// Lancer : node server.js   (variables : PORT, DATA_FILE, ACCESS_USER, ACCESS_PASS)
const http=require('http'), fs=require('fs'), path=require('path');
const PORT=process.env.PORT||3000;
const PUB=path.join(__dirname,'public');
const DATA=process.env.DATA_FILE||path.join(__dirname,'data','saisies.json');
const USER=process.env.ACCESS_USER, PASS=process.env.ACCESS_PASS;
const IDS=new Set(JSON.parse(fs.readFileSync(path.join(PUB,'products.js'),'utf8').replace(/^window\.PRODUCTS=/,'').replace(/;\s*$/,'')).map(p=>p.id));
const TYPES={'.html':'text/html; charset=utf-8','.js':'application/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json; charset=utf-8'};

fs.mkdirSync(path.dirname(DATA),{recursive:true});
function load(){try{return JSON.parse(fs.readFileSync(DATA,'utf8'))}catch(e){return {items:{}}}}
let db=load(), queue=Promise.resolve();
function persist(){ // écriture atomique : fichier temporaire puis renommage
  const tmp=DATA+'.tmp'; fs.writeFileSync(tmp,JSON.stringify(db,null,2)); fs.renameSync(tmp,DATA);
}
function send(res,code,body,type='application/json; charset=utf-8'){res.writeHead(code,{'Content-Type':type,'Cache-Control':'no-store'});res.end((typeof body==='string'||Buffer.isBuffer(body))?body:JSON.stringify(body));}
function authOk(req){
  if(!USER) return true;
  const h=req.headers.authorization||''; const [t,v]=h.split(' ');
  if(t!=='Basic'||!v) return false;
  const [u,...p]=Buffer.from(v,'base64').toString().split(':'); return u===USER&&p.join(':')===PASS;
}
http.createServer((req,res)=>{
  if(!authOk(req)){res.writeHead(401,{'WWW-Authenticate':'Basic realm="Saisie des prix"'});return res.end('Accès protégé');}
  const url=new URL(req.url,'http://x');
  if(url.pathname==='/api/data'){
    if(req.method==='GET') return send(res,200,db);
    if(req.method==='POST'){
      let body=''; req.on('data',c=>{body+=c; if(body.length>10000) req.destroy();});
      req.on('end',()=>{queue=queue.then(()=>{
        let j; try{j=JSON.parse(body)}catch(e){return send(res,400,{error:'JSON invalide'})}
        if(!IDS.has(j.id)) return send(res,400,{error:'Produit inconnu'});
        const prix=j.prix==null||j.prix===''?null:Number(j.prix);
        if(prix!=null&&(!isFinite(prix)||prix<0||prix>10000000)) return send(res,400,{error:'Prix invalide'});
        db.items[j.id]={done:!!j.done,prix,updated:new Date().toISOString()};
        db.updated=new Date().toISOString();
        try{persist()}catch(e){return send(res,500,{error:'Écriture impossible'})}
        send(res,200,db);
      });});
      return;
    }
    return send(res,405,{error:'Méthode non autorisée'});
  }
  if(url.pathname==='/api/export'){res.setHeader('Content-Disposition','attachment; filename="saisies.json"');return send(res,200,db);}
  let f=path.normalize(path.join(PUB,url.pathname==='/'?'index.html':decodeURIComponent(url.pathname)));
  if(!f.startsWith(PUB)) return send(res,403,'Interdit','text/plain');
  fs.readFile(f,(err,buf)=>{ if(err) return send(res,404,'Introuvable','text/plain'); send(res,200,buf,TYPES[path.extname(f)]||'application/octet-stream'); });
}).listen(PORT,()=>console.log(`Saisie des prix : http://localhost:${PORT}  (données : ${DATA})`));
