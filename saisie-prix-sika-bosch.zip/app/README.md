# Saisie des prix Sika et Bosch

Application web pour vérifier les 93 produits (35 Sika, 58 Bosch) : prix relevés sur Bricoma, Mr Bricolage, Bricop et Outillage Aouami, case « Traité », champ « Prix correct », avancement en %.
Pas de base de données : toutes les saisies sont enregistrées dans **un seul fichier JSON** : `data/saisies.json`.

## Contenu
```
server.js          serveur Node.js (aucune dépendance à installer)
public/index.html  la page
public/app.js      logique de la page
public/app.css     styles (mode clair, sans couleurs)
public/products.js liste des produits et prix relevés
public/api.php     version PHP de l'API (hébergement mutualisé)
data/              dossier où est créé saisies.json
```

## Option A — Serveur Node.js (VPS)
1. Copier le dossier sur le serveur (Node.js 16 ou plus récent).
2. Lancer :
   ```
   ACCESS_USER=client ACCESS_PASS=motdepasse PORT=3000 node server.js
   ```
   `ACCESS_USER` / `ACCESS_PASS` sont facultatifs mais conseillés : la page demande alors un identifiant et un mot de passe.
3. Pour qu'il tourne en permanence : `pm2 start server.js --name prix` (ou un service systemd), avec Nginx devant pour le HTTPS.

## Option B — Hébergement PHP (cPanel, Plesk…)
1. Envoyer le contenu de `public/` dans le dossier web (ex. `public_html/prix/`).
2. Créer le dossier `data/` **un niveau au-dessus** de ce dossier (ex. `public_html/data/`) avec les droits d'écriture (775). Le fichier `saisies.json` s'y crée tout seul.
3. Protéger l'accès par mot de passe avec l'outil « Protection de répertoire » de l'hébergeur.

La page détecte automatiquement `api.php`.

## Récupérer les saisies du client
- le fichier `data/saisies.json` sur le serveur ;
- ou les boutons **Exporter JSON** / **Exporter CSV (Excel)** de la page ;
- ou l'adresse `/api/export` (version Node).

Format de `saisies.json` :
```json
{ "items": { "Sika-6430": { "done": true, "prix": 265, "updated": "2026-10-12T13:45:31Z" } }, "updated": "..." }
```
L'identifiant = marque + référence (+ variante).

## Bon à savoir
- Chaque modification n'envoie que la ligne concernée : plusieurs personnes peuvent saisir en même temps sans s'écraser. La page se met à jour toutes les 30 secondes.
- Écriture sécurisée du fichier (fichier temporaire puis remplacement en Node, verrou en PHP).
- Ouverte sans serveur (double-clic sur index.html), la page passe en « Mode local » : les saisies restent dans le navigateur ; les exporter en JSON. « Importer JSON » recharge un export.
- Sauvegarder `data/saisies.json` régulièrement (simple copie du fichier).
