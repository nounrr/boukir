(function(){
const ROWS=window.PRODUCTS||[];
const SITES=[['BR','Bricoma'],['MB','Mr Bricolage'],['BP','Bricop'],['AO','Outillage Aouami']];
const LS='saisies-prix-v1';
let SAVE={}, mode='server', api=null, brand='all', filter='all', pending=0;
const $=s=>document.querySelector(s);
const fmt=v=>v==null||v===''?'':Number(v).toLocaleString('fr-MA',{minimumFractionDigits:2,maximumFractionDigits:2});
const esc=s=>String(s??'').replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const SUB=()=>brand==='all'?ROWS:ROWS.filter(r=>r.b===brand);
const isDone=id=>!!(SAVE[id]&&SAVE[id].done);
const prixOf=id=>SAVE[id]&&SAVE[id].prix!=null?SAVE[id].prix:null;

function setStatus(msg){$('#status').innerHTML=msg}
function now(){return new Date().toLocaleTimeString('fr-MA',{hour:'2-digit',minute:'2-digit'})}

async function detect(){
  for(const u of ['api/data','api.php']){
    try{const r=await fetch(u,{cache:'no-store'}); if(r.ok&&(r.headers.get('content-type')||'').includes('json')){api=u; SAVE=(await r.json()).items||{}; mode='server'; setStatus(`<b>Connecté au serveur</b> · données chargées à ${now()}`); return;}}catch(e){}
  }
  mode='local'; try{SAVE=JSON.parse(localStorage.getItem(LS)||'{}')}catch(e){SAVE={}}
  setStatus('<b>Mode local</b> · pas de serveur détecté : les saisies restent dans ce navigateur. Utilisez « Exporter JSON ».');
}
async function save(id){
  const it=SAVE[id]||{};
  if(mode==='local'){try{localStorage.setItem(LS,JSON.stringify(SAVE))}catch(e){} setStatus(`<b>Mode local</b> · enregistré dans ce navigateur à ${now()}`); return true;}
  pending++; setStatus('Enregistrement…');
  try{
    const r=await fetch(api,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id,done:!!it.done,prix:it.prix??null})});
    if(!r.ok) throw new Error(r.status);
    const j=await r.json(); pending--; if(j.items){ SAVE={...j.items}; }
    setStatus(`<b>Enregistré</b> sur le serveur à ${now()}`); return true;
  }catch(e){pending--; setStatus('<b>Erreur d’enregistrement</b> · vérifiez la connexion puis modifiez à nouveau la ligne.'); return false;}
}
async function refresh(){
  if(mode!=='server'||pending) return;
  if(document.activeElement&&document.activeElement.matches('.inp input')) return;
  try{const r=await fetch(api,{cache:'no-store'}); if(r.ok){SAVE=(await r.json()).items||{}; stats(); render(); setStatus(`<b>Connecté au serveur</b> · mis à jour à ${now()}`);}}catch(e){}
}

function stats(){
  const R=SUB(), N=R.length, done=R.filter(r=>isDone(r.id)).length, pct=N?Math.round(done/N*100):0;
  const br=R.filter(r=>r.s.BR).length, none=R.filter(r=>r.ret==null).length, filled=R.filter(r=>prixOf(r.id)!=null).length;
  $('#plbl').textContent=`${done} / ${N} produits traités`; $('#ppct').textContent=pct+' %'; $('#pbar').style.width=pct+'%';
  $('#pbar').parentElement.setAttribute('aria-valuenow',pct);
  $('#stats').innerHTML=[[N,'Produits'],[br,'Sur Bricoma'],[N-br,'Absents de Bricoma'],[N-br-none,'Trouvés ailleurs'],[none,'Introuvables partout'],[filled,'Prix correct saisi']]
    .map(([n,l])=>`<div class="stat"><b>${n}</b><span>${l}</span></div>`).join('');
}
function cell(r,k){const s=r.s[k];return `<td class="num price">${s?`<a href="${esc(s.u)}" target="_blank" rel="noopener">${fmt(s.p)}</a>`:'<span class="no">—</span>'}</td>`}
function render(){
  const q=$('#q').value.trim().toLowerCase();
  const list=SUB().filter(r=>{
    if(q&&!(r.n.toLowerCase().includes(q)||String(r.ref).toLowerCase().includes(q)))return false;
    if(filter==='todo')return !isDone(r.id);
    if(filter==='done')return isDone(r.id);
    if(filter==='nobr')return !r.s.BR;
    if(filter==='none')return r.ret==null;
    if(filter==='above')return r.ret!=null&&r.pv&&r.pv>r.ret;
    return true;});
  $('#tb').innerHTML=list.map(r=>{
    const g=(r.ret!=null&&r.pv)?r.pv-r.ret:null, d=isDone(r.id), p=prixOf(r.id);
    return `<tr class="${d?'done':''}" data-id="${esc(r.id)}">
      <td class="ck"><input type="checkbox" id="ck-${esc(r.id)}" ${d?'checked':''} aria-label="Marquer comme traité : ${esc(r.n)}"></td>
      <td><div class="pname">${esc(r.n)}</div><div class="meta"><span class="tag">${esc(r.b)}</span>Réf. ${esc(r.ref)} · Stock ${esc(r.stock)}</div>${r.note?`<div class="note">${esc(r.note)}</div>`:''}</td>
      <td class="num">${r.pv?fmt(r.pv):'<span class="no">—</span>'}</td>
      ${SITES.map(([k])=>cell(r,k)).join('')}
      <td class="num ret">${r.ret!=null?fmt(r.ret)+`<small>${esc(r.m)}</small>`:'<span class="no">Non trouvé</span>'}</td>
      <td class="num">${g!=null?(g>0?'+':'')+fmt(g)+`<div class="meta">${(g>0?'+':'')+(g/r.ret*100).toFixed(1)} %</div>`:''}</td>
      <td class="inp"><input type="number" inputmode="decimal" min="0" step="0.01" id="px-${esc(r.id)}" value="${p!=null?p:''}" placeholder="MAD" aria-label="Prix correct : ${esc(r.n)}"></td>
    </tr>`}).join('');
  $('#empty').hidden=list.length>0;
}
document.addEventListener('change',async e=>{
  const tr=e.target.closest('tr[data-id]'); if(!tr) return; const id=tr.dataset.id;
  SAVE[id]=SAVE[id]||{};
  if(e.target.type==='checkbox'){SAVE[id].done=e.target.checked; tr.classList.toggle('done',e.target.checked);}
  if(e.target.type==='number'){const v=e.target.value.trim(); SAVE[id].prix=v===''?null:Math.round(parseFloat(v.replace(',','.'))*100)/100; e.target.classList.remove('saved');}
  stats(); const ok=await save(id);
  if(ok&&e.target.type==='number'){const el=document.getElementById(e.target.id); if(el) el.classList.add('saved');}
});
document.querySelectorAll('[data-b]').forEach(b=>b.addEventListener('click',()=>{brand=b.dataset.b;document.querySelectorAll('[data-b]').forEach(x=>x.setAttribute('aria-pressed',x===b));stats();render();}));
document.querySelectorAll('[data-f]').forEach(b=>b.addEventListener('click',()=>{filter=b.dataset.f;document.querySelectorAll('[data-f]').forEach(x=>x.setAttribute('aria-pressed',x===b));render();}));
$('#q').addEventListener('input',render);

function download(name,text,type){const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([text],{type}));a.download=name;document.body.appendChild(a);a.click();setTimeout(()=>{URL.revokeObjectURL(a.href);a.remove()},500);}
const stamp=()=>new Date().toISOString().slice(0,10);
$('#xjson').addEventListener('click',()=>{
  const out=ROWS.map(r=>({id:r.id,marque:r.b,designation:r.n,reference:r.ref,prix_actuel:r.pv||null,prix_retenu:r.ret,traite:isDone(r.id),prix_correct:prixOf(r.id),modifie_le:(SAVE[r.id]||{}).updated||null}));
  download(`saisies-prix-${stamp()}.json`,JSON.stringify({exporte_le:new Date().toISOString(),produits:out},null,2),'application/json');});
$('#xcsv').addEventListener('click',()=>{
  const q=v=>`"${String(v??'').replace(/"/g,'""')}"`;
  const head=['Marque','Désignation','Référence','Stock','Prix actuel',...SITES.map(s=>'Prix '+s[1]),'Prix retenu','Traité','Prix correct','Modifié le'];
  const lines=ROWS.map(r=>[r.b,r.n,r.ref,r.stock,r.pv||'',...SITES.map(([k])=>r.s[k]?r.s[k].p:''),r.ret??'',isDone(r.id)?'Oui':'Non',prixOf(r.id)??'',(SAVE[r.id]||{}).updated||''].map(q).join(';'));
  download(`saisies-prix-${stamp()}.csv`,'﻿'+[head.map(q).join(';'),...lines].join('\r\n'),'text/csv');});
$('#imp').addEventListener('change',async e=>{
  const f=e.target.files[0]; if(!f) return; e.target.value='';
  try{const j=JSON.parse(await f.text()); const list=j.produits||[]; let n=0;
    for(const p of list){ if(!p.id||!ROWS.some(r=>r.id===p.id)) continue; SAVE[p.id]={...(SAVE[p.id]||{}),done:!!p.traite,prix:p.prix_correct??null}; await save(p.id); n++; }
    stats(); render(); setStatus(`<b>Import terminé</b> · ${n} produits mis à jour à ${now()}`);
  }catch(err){setStatus('<b>Import impossible</b> · le fichier n’est pas un export JSON de cette page.');}
});

(async()=>{await detect(); stats(); render(); setInterval(refresh,30000); window.addEventListener('focus',refresh);})();
})();
