<?php
// Version PHP (hébergement mutualisé) — même API que server.js.
// Les saisies sont enregistrées dans ../data/saisies.json (hors du dossier public).
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
$dataFile = __DIR__ . '/../data/saisies.json';
if (!is_dir(dirname($dataFile))) { mkdir(dirname($dataFile), 0775, true); }
$src = file_get_contents(__DIR__ . '/products.js');
$src = preg_replace('/^window\.PRODUCTS=/', '', trim($src)); $src = rtrim($src, ';');
$ids = array_column(json_decode($src, true), 'id');

$fp = fopen($dataFile, 'c+');
if (!$fp) { http_response_code(500); echo json_encode(['error' => 'Écriture impossible']); exit; }
flock($fp, LOCK_EX);
$raw = stream_get_contents($fp);
$db = $raw ? json_decode($raw, true) : null;
if (!is_array($db)) { $db = ['items' => new stdClass()]; }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $j = json_decode(file_get_contents('php://input'), true);
  if (!is_array($j) || !in_array($j['id'] ?? '', $ids, true)) { http_response_code(400); echo json_encode(['error' => 'Produit inconnu']); flock($fp, LOCK_UN); exit; }
  $prix = (isset($j['prix']) && $j['prix'] !== '' && $j['prix'] !== null) ? (float)$j['prix'] : null;
  if ($prix !== null && ($prix < 0 || $prix > 10000000)) { http_response_code(400); echo json_encode(['error' => 'Prix invalide']); flock($fp, LOCK_UN); exit; }
  $items = (array)($db['items'] ?? []);
  $items[$j['id']] = ['done' => !empty($j['done']), 'prix' => $prix, 'updated' => gmdate('c')];
  $db['items'] = $items; $db['updated'] = gmdate('c');
  ftruncate($fp, 0); rewind($fp);
  fwrite($fp, json_encode($db, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
  fflush($fp);
}
flock($fp, LOCK_UN); fclose($fp);
if (empty($db['items'])) { $db['items'] = new stdClass(); }
echo json_encode($db, JSON_UNESCAPED_UNICODE);
